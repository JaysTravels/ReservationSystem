﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Models
{
    public class ReferencingDetail
    {
        public int? refNumber { get; set; }
        public string? refQualifier { get; set; }
    }
}
