﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Models
{
    public class Co2Emissions
    {
        public string? weight { get; set; }
        public string? weightUnit { get; set; }
        public string? cabin { get; set; }
    }
}
