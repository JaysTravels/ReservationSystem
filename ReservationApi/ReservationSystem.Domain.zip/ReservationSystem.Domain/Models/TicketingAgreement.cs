﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Models
{
    public class TicketingAgreement
    {
        public string? option { get; set; }
        public string? delay { get; set; }
    }
}
