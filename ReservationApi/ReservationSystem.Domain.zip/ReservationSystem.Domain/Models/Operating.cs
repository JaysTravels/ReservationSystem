﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Models
{
    public class Operating
    {
        public string? operatingCarrierCode { get; set; }
        public string? operatingCarrierName { get; set; }
    }
}
